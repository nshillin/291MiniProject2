Remove reviews.txt, pterms.txt, prterms.txt, scores.txt, rw.idx, pt.idx, rt.idx, and sc.idx.
Run SetUpScript and enter the name of the records file you want imported.
Run “python Phase3.py” and enter your queries when prompted.